#ifndef GAME_H
#define GAME_H

int startGame(void);

#endif